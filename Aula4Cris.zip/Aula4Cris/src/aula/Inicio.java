package aula;

public class Inicio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pessoas objPes = new Pessoas();
		objPes.setIdPessoa(2);
		objPes.setNome("Pessoa 2");
		objPes.setEmail("pessoa@gmail");
		objPes.setEndereço("Rua Izidro");
		objPes.setCEP("11668-040");
		objPes.setTelefone("12 996110886");
		
		objPes.Consultar();
		
		Juridica objJur = new Juridica();
		objJur.setIdPessoa(7);
		objJur.setNome("Empresa ENIAC");
		objJur.setEndereço("Rua Machado");
		objJur.setCEP("123154");
		objJur.setTelefone("12 99838556");
		objJur.setCNPJ("01.123.123/0001-12");
		objJur.setInsEstadual("Insento");
		
		objJur.Consultar_Empresa();
		

	}

}
