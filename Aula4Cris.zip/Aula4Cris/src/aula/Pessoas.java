package aula;

public class Pessoas {
	protected int IdPessoa;
	protected String Nome, Email, Endereço, CEP, Telefone;
	
	public int getIdPessoa() {
		return this.IdPessoa;
	}
	public void setIdPessoa(int _id) {
		this.IdPessoa = _id;
	}
	public String getNome() {
		return this.Nome;
	}
	public void setNome(String _nome) {
		this.Nome = _nome;
	}
	public String getEmail() {
		return this.Email;
	}
	public void setEmail(String _email) {
		this.Email = _email;
	}
	public String getEndereço() {
		return this.Endereço;
	}
	public void setEndereço(String _endereço) {
		this.Endereço = _endereço;
	}
	public String getCEP() {
		return this.CEP;
	}
	public void setCEP(String _cep) {
		this.CEP = _cep;
	}
	public String getTelefone() {
		return this.Telefone;
	}
	public void setTelefone(String _tel) {
		this.Telefone = _tel;
	}
	
	public int Consultar() {
		System.out.println("IdPessoa: " + this.getIdPessoa());
		System.out.println("Nome: " + this.getNome());
		System.out.println("Email: " + this.getEmail());
		System.out.println("Endereço: " + this.getEndereço());
		System.out.println("CEP: " + this.getCEP());
		System.out.println("Telefone: " + this.getTelefone());
		System.out.println("=======================");
		return 0;
	}

}
