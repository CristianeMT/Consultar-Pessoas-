package aula;

public class Fisica extends Pessoas {
public String CPF, RG;
	
	public String getCPF() {
		return this.CPF;
	}
	public void setCPF(String _cpf) {
		this.CPF = _cpf;
	}
	public String getRG() {
		return this.RG;
	}
	public void setRG(String _rg) {
		this.RG = _rg;
	}
	
	public void Consultar_Cliente() {
		this.Consultar();
		System.out.println("CPF: " + this.getCPF());
		System.out.println("RG: " + this.getRG());
		System.out.println("=======================");
	}

}
