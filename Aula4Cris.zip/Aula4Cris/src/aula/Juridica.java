package aula;

public class Juridica extends Pessoas{
	public String CNPJ, InsEstadual;
	
	public String getCNPJ() {
		return this.CNPJ;
	}
	public void setCNPJ(String _cnpj) {
		this.CNPJ = _cnpj;
	}
	public String getInsEstadual() {
		return this.InsEstadual;
	}
	public void setInsEstadual(String _insestadual) {
		this.InsEstadual = _insestadual;
	}
	
	public void Consultar_Empresa() {
		this.Consultar();
		System.out.println("CNPJ: " + this.getCNPJ());
		System.out.println("Inscrição Estadual: " + this.getInsEstadual());
		System.out.println("=======================");
	}

}
